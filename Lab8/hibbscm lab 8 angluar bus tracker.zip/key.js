/**
 * Created by hornick on 4/12/2016.
 * Connor Hibbs's Keys
 * This file contains your http://realtime.ridemcts.com developer's key
 */
var key = "cpT5eAHGGFGPUnM8xP6gyLUWE";

// maps key AIzaSyB6lYG5g3lhZ5Ruy1BgC5keh0YTD0hZo0k